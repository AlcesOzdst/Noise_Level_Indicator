Adding Microphone Library for Proteus
STEP 2: Download the file to the desktop

STEP 3: Unzip the .zip file to the desktop

STEP 4: You will obtain these three files:

    Library
    Models
    Samples

STEP 5: Copy the library folder’s file and paste it in:

Go to “C:\Program Files (x86)\Labcenter Electronics\Proteus 7 Professional\LIBRARY“

              Copy the Models folder’s file and paste it in:

Go to “C:\Program Files (x86)\Labcenter Electronics\Proteus 7 Professional\Models”

              Copy the Sample folder’s file(Microphone demo) and paste it in:

Go to “C:\Program Files (x86)\Labcenter Electronics\Proteus 7 Professional\Samples“

Note: In case you can’t find the Library folder in Proteus 8, first unhide the hidden items from the view menu. Then Go to—-> C:\ProgramData\Labcenter Electronics\Proteus 8 Professional\LIBRARY

STEP 6: Open proteus and click on “pick from libraries”

STEP 7: Search for “Microphone” in the component section, you will see “Microphone”. Select it.

How to use this microphone?

STEP 8: Go to help/Sample designs

STEP 9:  Now open the folder: ‘Microphone Demo’ and then the file ‘Model’ :